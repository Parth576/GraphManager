package com.parth.project;

public interface SearchStrategy {
    public GraphManager.Path search(String src, String dst);
}
